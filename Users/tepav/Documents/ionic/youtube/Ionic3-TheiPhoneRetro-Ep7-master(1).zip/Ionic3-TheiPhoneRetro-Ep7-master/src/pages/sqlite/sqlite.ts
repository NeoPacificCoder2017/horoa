import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-sqlite',
  templateUrl: 'sqlite.html'
})
export class SQLitePage {

  constructor(public navCtrl: NavController) {

  }

}
